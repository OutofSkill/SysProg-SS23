#include "../lib/MLF.h"
#include <stdlib.h>

static queue_object** MLF_queues;
static int zeitscheibe;

int calculate_zeitscheibe(int Ebene) {
    if (Ebene > 1) {
        return Ebene * calculate_zeitscheibe(Ebene - 1);
    } else {
        return 1;
    }
}
//TODO:
// - 
process* MLF_tick(process* running_process) {
    if (running_process == NULL || running_process -> time_left == 0 || zeitscheibe == 0) {
        if (running_process && running_process -> time_left > 0) {
            queue_add(running_process, MLF_queues[running_process -> start_time++]);
        }
        if(MLF_queues[1]-> next != NULL){
            running_process = queue_poll(MLF_queues[1]);
            running_process -> start_time = 1; 
            zeitscheibe = calculate_zeitscheibe(running_process -> start_time);            
        }
        if(MLF_queues[2] -> next != NULL){
            running_process = queue_poll(MLF_queues[2]);
            running_process -> start_time = 2; 
            zeitscheibe = calculate_zeitscheibe(running_process -> start_time);  
        } 
        if(MLF_queues[3] -> next != NULL){
            running_process = queue_poll(MLF_queues[3]);
            running_process -> start_time = 3; 
            zeitscheibe = calculate_zeitscheibe(running_process -> start_time);              
        }
        if(MLF_queues[3] -> next != NULL){
            running_process = queue_poll(MLF_queues[4]);
            running_process -> start_time = 4; 
            zeitscheibe = running_process -> time_left;             
        }
    }

    if (running_process){
        running_process -> time_left--;
        zeitscheibe--;
    }

    return running_process;
}

int MLF_startup() {
    MLF_queues = calloc(5, sizeof(queue_object*));
    for (int i = 1; i < 5; i++) {
        MLF_queues[i] = new_queue();
    }
    return 0;
}

process* MLF_new_arrival(process* arriving_process, process* running_process) {
    if (arriving_process != NULL) {
        queue_add(arriving_process, MLF_queues[1]);
        arriving_process->start_time = 1;
    }
    return running_process;
}

void MLF_finish() {
    for (int i = 1; i < 5; i++) {
        if (MLF_queues[i] != NULL) {
            free_queue(MLF_queues[i]);
        }
    }
    free(MLF_queues);
}
